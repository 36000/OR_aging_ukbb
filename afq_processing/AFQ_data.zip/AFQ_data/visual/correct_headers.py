import nibabel as nib
ref_image = nib.load("left_OR_1.nii.gz")
for file_name in ["left_OP_MNI", "left_pos_thal_MNI"]
